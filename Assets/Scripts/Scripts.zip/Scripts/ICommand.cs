public interface ICommand
{
    void Execute(PlayerModel model);
}