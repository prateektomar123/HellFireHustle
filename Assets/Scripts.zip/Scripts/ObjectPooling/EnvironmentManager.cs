﻿using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class PlatformPrefab
{
    public GameObject prefab;
}

public class EnvironmentManager : MonoBehaviour
{
    [SerializeField] private PlatformPrefab[] platformPrefabs;
    [SerializeField] private Transform player;
    [SerializeField] private int initialPoolSize = 5;
    private GenericObjectPool<Platform> platformPool;
    private Queue<Platform> activePlatforms;
    private LaneState currentPlayerLane;
    private readonly float laneDistance = 2f; // Matches PlayerController
    private readonly float platformLength = 10f; // Matches Phase 3
    private readonly float spawnDistance = 5f; // Halfway for side lanes
    private float lastSpawnZ;

    private void Awake()
    {
        if (platformPrefabs.Length == 0 || platformPrefabs[0].prefab == null)
        {
            Debug.LogError("EnvironmentManager: No platform prefabs assigned.");
            return;
        }

        platformPool = new GenericObjectPool<Platform>(platformPrefabs[0].prefab, initialPoolSize, transform);
        activePlatforms = new Queue<Platform>();
        ServiceLocator.Instance.RegisterService(this);

        var eventSystem = ServiceLocator.Instance.GetService<EventSystem>();
        if (eventSystem != null)
        {
            eventSystem.Subscribe("PlayerMoved", OnPlayerMoved);
        }
        else
        {
            Debug.LogError("EventSystem not found in EnvironmentManager.Awake.");
        }
    }

    private void Start()
    {
        currentPlayerLane = new MiddleLaneState(null); // Temporary initialization
        SpawnInitialPlatform();
        lastSpawnZ = activePlatforms.Peek().GetHalfwayPointZ();
    }

    private void Update()
    {
        if (!player || !Camera.main) return;

        // Check oldest platform
        if (activePlatforms.Count > 0)
        {
            Platform oldestPlatform = activePlatforms.Peek();
            float playerZ = player.position.z;
            if (playerZ >= oldestPlatform.GetHalfwayPointZ())
            {
                SpawnNextPlatform();
                RecycleOldestPlatform(playerZ);
            }
        }
    }

    private void OnPlayerMoved(object data)
    {
        currentPlayerLane = data as LaneState;
        Debug.Log($"Player lane updated: {currentPlayerLane?.GetType().Name ?? "Null"}");
    }

    private void SpawnInitialPlatform()
    {
        Platform platform = platformPool.GetObject();
        platform.Initialize(platformLength, 0); // Middle lane
        platform.transform.position = new Vector3(0, 0, 0);
        activePlatforms.Enqueue(platform);
        Debug.Log("Spawned initial platform at X: 0, Z: 0");
    }

    private void SpawnNextPlatform()
    {
        float nextZ = lastSpawnZ + platformLength;
        float nextX = 0;

        switch (currentPlayerLane)
        {
            case MiddleLaneState:
                int laneChoice = Random.Range(0, 3); // 0: Left, 1: Middle, 2: Right
                Debug.Log($"Middle lane choice: {laneChoice}");
                nextX = laneChoice switch
                {
                    0 => -laneDistance, // Left
                    1 => 0,             // Middle
                    _ => laneDistance   // Right
                };
                if (laneChoice != 1) // Not Middle
                {
                    nextZ = lastSpawnZ + (platformLength / 2f);
                }
                break;

            case LeftLaneState:
                nextX = Random.value < 0.5f ? -laneDistance : 0; // Left or Middle
                if (nextX == 0) nextZ -= spawnDistance; // Spawn Middle earlier
                break;

            case RightLaneState:
                nextX = Random.value < 0.5f ? laneDistance : 0; // Right or Middle
                if (nextX == 0) nextZ -= spawnDistance; // Spawn Middle earlier
                break;

            default:
                nextX = 0; // Fallback to Middle
                Debug.LogWarning("Fallback to Middle lane due to null or invalid lane state");
                break;
        }

        Platform platform = platformPool.GetObject();
        platform.Initialize(platformLength, nextX);
        platform.transform.position = new Vector3(nextX, 0, nextZ);
        activePlatforms.Enqueue(platform);
        Debug.Log($"Spawned platform at X: {nextX}, Z: {nextZ}");
        lastSpawnZ = nextZ;
    }

    private void RecycleOldestPlatform(float playerZ)
    {
        if (activePlatforms.Count == 0) return;

        Platform oldestPlatform = activePlatforms.Peek();
        if (playerZ > oldestPlatform.transform.position.z + platformLength)
        {
            platformPool.ReturnObject(oldestPlatform);
            activePlatforms.Dequeue();
        }
    }

    private void OnDestroy()
    {
        var eventSystem = ServiceLocator.Instance.GetService<EventSystem>();
        if (eventSystem != null)
        {
            eventSystem.Unsubscribe("PlayerMoved", OnPlayerMoved);
        }
        ServiceLocator.Instance.RemoveService<EnvironmentManager>();
    }
}